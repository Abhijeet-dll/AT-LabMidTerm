import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Spinner colorSpinner;
    private Button changeBackgroundButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        colorSpinner = findViewById(R.id.colorSpinner);
        changeBackgroundButton = findViewById(R.id.changeBackgroundButton);

        // Define colors to display in the spinner
        final String[] colors = {"Red", "Green", "Blue", "Yellow", "Cyan", "Magenta"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, colors);
        colorSpinner.setAdapter(adapter);

        colorSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Nothing to do here since we'll handle background change on button click
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No action needed
            }
        });
    }

    public void changeBackground(View view) {
        String selectedColor = (String) colorSpinner.getSelectedItem();

        int backgroundColor;
        switch (selectedColor) {
            case "Red":
                backgroundColor = Color.RED;
                break;
            case "Green":
                backgroundColor = Color.GREEN;
                break;
            case "Blue":
                backgroundColor = Color.BLUE;
                break;
            case "Yellow":
                backgroundColor = Color.YELLOW;
                break;
            case "Cyan":
                backgroundColor = Color.CYAN;
                break;
            case "Magenta":
                backgroundColor = Color.MAGENTA;
                break;
            default:
                backgroundColor = Color.WHITE; // Default to white if no valid color selected
        }

        findViewById(android.R.id.content).setBackgroundColor(backgroundColor);
    }
}
