import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText inputEditText;
    TextView encryptedTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputEditText = findViewById(R.id.inputEditText);
        encryptedTextView = findViewById(R.id.encryptedTextView);
    }

    public void encryptText(View view) {
        String inputText = inputEditText.getText().toString();
        String encryptedText = encrypt(inputText);
        encryptedTextView.setText("Encrypted text: " + encryptedText);
    }

    private String encrypt(String input) {
        // Simple encryption algorithm (shifting characters by 1)
        StringBuilder encrypted = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (Character.isLetter(c)) {
                if (Character.isUpperCase(c)) {
                    encrypted.append((char) ('A' + (c - 'A' + 1) % 26));
                } else {
                    encrypted.append((char) ('a' + (c - 'a' + 1) % 26));
                }
            } else {
                encrypted.append(c); // Keep non-alphabetic characters unchanged
            }
        }
        return encrypted.toString();
    }
}
