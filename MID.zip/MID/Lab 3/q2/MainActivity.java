import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RadioGroup ratingRadioGroup;
    private EditText commentEditText;
    private TextView feedbackListTextView;

    private ArrayList<Feedback> feedbackList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ratingRadioGroup = findViewById(R.id.ratingRadioGroup);
        commentEditText = findViewById(R.id.commentEditText);
        feedbackListTextView = findViewById(R.id.feedbackListTextView);

        feedbackList = new ArrayList<>();
    }

    public void submitFeedback(View view) {
        int selectedRatingId = ratingRadioGroup.getCheckedRadioButtonId();
        if (selectedRatingId == -1) {
            Toast.makeText(this, "Please select a rating", Toast.LENGTH_SHORT).show();
            return;
        }

        RadioButton selectedRatingRadioButton = findViewById(selectedRatingId);
        String rating = selectedRatingRadioButton.getText().toString();
        String comment = commentEditText.getText().toString();

        Feedback feedback = new Feedback(rating, comment);
        feedbackList.add(feedback);
        updateFeedbackHistory();
        clearFields();
        Toast.makeText(this, "Feedback submitted successfully", Toast.LENGTH_SHORT).show();
    }

    private void updateFeedbackHistory() {
        StringBuilder feedbackHistory = new StringBuilder();
        for (Feedback feedback : feedbackList) {
            feedbackHistory.append("Rating: ").append(feedback.getRating()).append(", Comment: ").append(feedback.getComment()).append("\n\n");
        }
        feedbackListTextView.setText(feedbackHistory.toString());
    }

    private void clearFields() {
        ratingRadioGroup.clearCheck();
        commentEditText.setText("");
    }
}

