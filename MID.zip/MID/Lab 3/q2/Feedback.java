public class Feedback {
    private String rating;
    private String comment;

    public Feedback(String rating, String comment) {
        this.rating = rating;
        this.comment = comment;
    }

    public String getRating() {
        return rating;
    }

    public String getComment() {
        return comment;
    }
}
